Alpha Flashing UI (UI Shaders).

The asset includes two shaders, one shader for text, the second for sprites.
Shaders allow you to get various effects(example gradient), not just a smooth change in transparency (see examples).

The asset includes a script that changes the transparency of the text. 
You can change the alpha channel for several texts at once by setting different parameters.


Full instructions - https://nvjob.github.io/unity/alpha-flashing-text

Distributed with MIT License.